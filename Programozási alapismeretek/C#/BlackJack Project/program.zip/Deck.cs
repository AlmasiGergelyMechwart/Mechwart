﻿namespace BlackJack
{
    public class Deck
    {
        //string[] deck = new string[52];
        List<string> deck = new ();
        string faceCards = "JQKA";
        string suits = "HDCS";

        Random rnd = new Random();

        public Deck()
        {
            for (int i = 0; i < 52; i++)
            {
                if (i % 13 <= 8)
                {
                    deck.Add(((i % 13) + 2).ToString() + suits[(int)(4 / (52 / (float)i))]);
                }
                else
                {
                    deck.Add(faceCards[(i % 13) - 9].ToString() + suits[(int)(4 / (52 / (float)i))].ToString());
                }
            }
        }

        public void Print()
        {
            for (int i = 0; i < deck.Count; i++)
            {
                if (deck[i].Length < 3)
                {
                    Console.Write(" ");
                }

                Console.Write(deck[i] + " ");

                if (i % 13 == 12)
                {
                    Console.WriteLine();
                }
            }
        }

        public void Shuffle()
        {
            for (int i = 0; i < deck.Count; i++)
            {
                int rand = rnd.Next(i, deck.Count);
                string temp = deck[i];
                deck[i] = deck[rand];
                deck[rand] = temp;
            }
        }

        public class Player
        {
            Deck deck;
            public Player(Deck d) { deck = d; }

            List<string> hand = new ();
            
            public List<int> points = new ();

            public void Print()
            {
                for (int i = 0; i < hand.Count; i++)
                {
                    Console.Write(hand[i] + " ");
                }
                Console.WriteLine();
            }

            public void Draw(string card)
            {
                // hand.Add(deck.deck[0]);
                hand.Add(card);
                deck.deck.RemoveAt(0);
                EstimateValue();
            }

            void EstimateValue() {
                points = new () {0};
                for (int i = 0; i < hand.Count; i++)
                {
                    // Console.WriteLine(hand[hand.Count-1][0]-'0');
                    /* J -> 26
                       Q -> 33
                       K -> 27
                       A -> 17 */
                    int firstChar = hand[i][0]-'0';
                    if (firstChar < 10 && firstChar > 1) // Number card
                    {
                        for (int j = 0; j < points.Count; j++)
                        {
                            points[j] += firstChar;
                        }
                    } else if (firstChar == 17) // Ace
                    {
                        for (int j = 0; j < points.Count; j++)
                        {
                            points[j] += 1;
                        }
                        points.Add(points[points.Count-1]);
                        points[points.Count-1] += 10;
                    } else // Face card or 10
                    {
                        for (int j = 0; j < points.Count; j++)
                        {
                            points[j] += 10;
                        }
                    }
                }
            }
        }
    }

}