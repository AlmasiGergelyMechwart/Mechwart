﻿//https://bicyclecards.com/how-to-play/blackjack
namespace BlackJack
{
    class Program
    {
        static void Main(string[] args)
        {
            Deck deck = new Deck();
            deck.Shuffle();
            deck.Print();

            Deck.Player player = new Deck.Player(deck);
            Deck.Player dealer = new Deck.Player(deck);

            // player.Draw("2D");
            player.Draw("6D");
            // player.Draw("9D");
            // player.Draw("10D");
            // player.Draw("JD");
            // player.Draw("QD");
            // player.Draw("KD");
            player.Draw("AD");
            player.Draw("AS");

            player.Print();
            foreach (int item in player.points)
            {
                Console.Write(item + " or ");
            } Console.WriteLine();
            Console.WriteLine(player.points.Count-1 + " db Ace");

            // dealer.Draw();
            // player.Draw();
            //dealer.Draw();

            // player.Print();
            // dealer.Print();

            // for (int i=0; i<101; i++) {
            //     Console.WriteLine(i + ": " + (char)i);
            // }
        }
    }
}