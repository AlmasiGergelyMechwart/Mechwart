# rpg-sheet

## Stength
2 dobás összege egy 6 oldalú kockával
### Defense
Strength * 1.7

## Constitution
3 dobás összege egy 3 oldalú kockával
### Hit points
Constitution * 2.2

## Dexterity
2 dobás összege egy 6 oldalú kockával
### Evasion
Dexterity * 0.8

## Luck
1 dobás egy 50 oldalú kockával (százalékot ad)
### Critical hit
Luck / 5 (százalék)

## Intelligence
3 dobás összege egy 6 oldalú kockával
### Damage
Intelligence * 1.5

## Armor
1 dobás egy 100 oldalú kockával
### Damage reduction - Armor / 2 (százalék)
